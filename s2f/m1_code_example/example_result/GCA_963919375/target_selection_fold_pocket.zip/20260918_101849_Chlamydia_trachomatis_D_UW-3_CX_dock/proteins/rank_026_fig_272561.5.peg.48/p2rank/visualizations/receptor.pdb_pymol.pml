from pymol import cmd,stored

set depth_cue, 1
set fog_start, 0.4

set_color b_col, [36,36,85]
set_color t_col, [10,10,10]
set bg_rgb_bottom, b_col
set bg_rgb_top, t_col      
set bg_gradient

set  spec_power  =  200
set  spec_refl   =  0

load "data/receptor.pdb", protein
create ligands, protein and organic
select xlig, protein and organic
delete xlig

hide everything, all

color white, elem c
color bluewhite, protein
#show_as cartoon, protein
show surface, protein
#set transparency, 0.15

show sticks, ligands
set stick_color, magenta






# SAS points

load "data/receptor.pdb_points.pdb.gz", points
hide nonbonded, points
show nb_spheres, points
set sphere_scale, 0.2, points
cmd.spectrum("b", "green_red", selection="points", minimum=0, maximum=0.7)


stored.list=[]
cmd.iterate("(resn STP)","stored.list.append(resi)")    # read info about residues STP
lastSTP=stored.list[-1] # get the index of the last residue
hide lines, resn STP

cmd.select("rest", "resn STP and resi 0")

for my_index in range(1,int(lastSTP)+1): cmd.select("pocket"+str(my_index), "resn STP and resi "+str(my_index))
for my_index in range(1,int(lastSTP)+1): cmd.show("spheres","pocket"+str(my_index))
for my_index in range(1,int(lastSTP)+1): cmd.set("sphere_scale","0.4","pocket"+str(my_index))
for my_index in range(1,int(lastSTP)+1): cmd.set("sphere_transparency","0.1","pocket"+str(my_index))



set_color pcol1 = [0.361,0.576,0.902]
select surf_pocket1, protein and id [4054,4607,4056,4076,4072,4052,5060,5076,5057,5054,5088,4560,5121,5188,5561,5138,5140,5108,5443,5441,4606,4620,4619,5105] 
set surface_color,  pcol1, surf_pocket1 
set_color pcol2 = [0.278,0.322,0.702]
select surf_pocket2, protein and id [3284,3223,3306,3222,3290,3254,6371,3260,3286,3262,3288,3285,3184,3085,4525,3101,3098,3185,3096,3100,4523,3097,4518,3102,3084,4527,3099,7704,7702,7705,7699,7672,7673,7674,6750,4094,4095,5079,3287,5078,6370,3289,5399,5037,5080,5092,4507,4526,5401,4522,4517,6385,6383,6386,5611,5609] 
set surface_color,  pcol2, surf_pocket2 
set_color pcol3 = [0.467,0.361,0.902]
select surf_pocket3, protein and id [1897,1896,1891,1927,1881,1895,1847,3621,3622,3618,3620,3623,3669,3688,1961,1516,3670,3667,1848,1894,161,4932,1946,1949,3739,1519,1518,4931,1517,4930,4858,4860,4933,3738] 
set surface_color,  pcol3, surf_pocket3 
set_color pcol4 = [0.490,0.278,0.702]
select surf_pocket4, protein and id [7547,7566,8004,8003,7593,7568,6455,6513,7115,6951,6947,6514,7117,6454,7203,7113,7202,7138,7047,7140,7048,7049] 
set surface_color,  pcol4, surf_pocket4 
set_color pcol5 = [0.792,0.361,0.902]
select surf_pocket5, protein and id [1881,161,158,152,123,122,1488,135,151,134,1490,4932,4790,1519,1518,1520,3389,4930,4856,4858,4854,4851,4850,4791,4789] 
set surface_color,  pcol5, surf_pocket5 
set_color pcol6 = [0.702,0.278,0.659]
select surf_pocket6, protein and id [5966,5968,5967,5974,6024,5975,8540,8538,5981,8537,5933,5931,8535,8687,8691,8689,8686,8688] 
set surface_color,  pcol6, surf_pocket6 
set_color pcol7 = [0.902,0.361,0.682]
select surf_pocket7, protein and id [2335,3239,2338,2336,2941,3258,7813,7814,7816,7611,7482] 
set surface_color,  pcol7, surf_pocket7 
set_color pcol8 = [0.702,0.278,0.408]
select surf_pocket8, protein and id [8877,8878,8519,8521,8518,8517,8850,8520,9253,9220,8561] 
set surface_color,  pcol8, surf_pocket8 
set_color pcol9 = [0.902,0.361,0.361]
select surf_pocket9, protein and id [8321,7389,8835,8499,7357,8834,8419,8418,8860,6003] 
set surface_color,  pcol9, surf_pocket9 
set_color pcol10 = [0.702,0.408,0.278]
select surf_pocket10, protein and id [298,290,1487,1491,135,1489,136,138,4722,1472,317,313,320,318,316,4730,4733,4729,4663,4401,4661,4718,4399] 
set surface_color,  pcol10, surf_pocket10 
set_color pcol11 = [0.902,0.682,0.361]
select surf_pocket11, protein and id [5533,5329,5311,5325,5536,5531,5511,5331,2141,2160,2173,6253,6231,6232,2180,2177] 
set surface_color,  pcol11, surf_pocket11 
set_color pcol12 = [0.702,0.659,0.278]
select surf_pocket12, protein and id [7453,7521,7280,7458,7278,6344,6341,7524,6331,7438,7324] 
set surface_color,  pcol12, surf_pocket12 




deselect

orient

from pymol import cmd,stored

set depth_cue, 1
set fog_start, 0.4

set_color b_col, [36,36,85]
set_color t_col, [10,10,10]
set bg_rgb_bottom, b_col
set bg_rgb_top, t_col      
set bg_gradient

set  spec_power  =  200
set  spec_refl   =  0

load "data/receptor.pdb", protein
create ligands, protein and organic
select xlig, protein and organic
delete xlig

hide everything, all

color white, elem c
color bluewhite, protein
#show_as cartoon, protein
show surface, protein
#set transparency, 0.15

show sticks, ligands
set stick_color, magenta






# SAS points

load "data/receptor.pdb_points.pdb.gz", points
hide nonbonded, points
show nb_spheres, points
set sphere_scale, 0.2, points
cmd.spectrum("b", "green_red", selection="points", minimum=0, maximum=0.7)


stored.list=[]
cmd.iterate("(resn STP)","stored.list.append(resi)")    # read info about residues STP
lastSTP=stored.list[-1] # get the index of the last residue
hide lines, resn STP

cmd.select("rest", "resn STP and resi 0")

for my_index in range(1,int(lastSTP)+1): cmd.select("pocket"+str(my_index), "resn STP and resi "+str(my_index))
for my_index in range(1,int(lastSTP)+1): cmd.show("spheres","pocket"+str(my_index))
for my_index in range(1,int(lastSTP)+1): cmd.set("sphere_scale","0.4","pocket"+str(my_index))
for my_index in range(1,int(lastSTP)+1): cmd.set("sphere_transparency","0.1","pocket"+str(my_index))



set_color pcol1 = [0.361,0.576,0.902]
select surf_pocket1, protein and id [998,993,994,1724,988,1723,991,297,296,295,294,292,320,590,290,293,291,289,1728,1734,1733,1732,1773,1022,1024,1757,1023,1755,1758,122,113,975,974,976,982,980,973,986,984,112,985,978,1715,1721,1717,1716,971,970,602,1156,1419,1424,1420,1450,1478,1449,977,1426,1477,1157,1428,995,1430,286,106,285,101,103,102,579,592,981,583,1771,1808,1781,1809,1807,141,1702,148,1695,1690,1698,153,1691,1689,151,1686,1692,144,1701,1412,1407,1356,1342,1336,1351,1357,1343,1352,1355,1335,1353,1354,1338] 
set surface_color,  pcol1, surf_pocket1 
set_color pcol2 = [0.490,0.278,0.702]
select surf_pocket2, protein and id [1845,1809,1831,1832,1830,1835,1834,2178,1878,1877,1407,1365,1408,1400,1392,1390,2172,1357] 
set surface_color,  pcol2, surf_pocket2 
set_color pcol3 = [0.902,0.361,0.682]
select surf_pocket3, protein and id [1550,1577,1205,1228,1202,1226,1233,1229,1622,1230,1607,1621,1579,1574,1580,1572] 
set surface_color,  pcol3, surf_pocket3 
set_color pcol4 = [0.702,0.408,0.278]
select surf_pocket4, protein and id [296,693,591,691,749,613,602,1156,611,601] 
set surface_color,  pcol4, surf_pocket4 




deselect

orient

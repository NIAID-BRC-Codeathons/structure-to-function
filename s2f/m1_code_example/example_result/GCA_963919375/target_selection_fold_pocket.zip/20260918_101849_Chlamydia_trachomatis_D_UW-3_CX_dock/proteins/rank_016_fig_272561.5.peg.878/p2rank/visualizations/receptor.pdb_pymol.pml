from pymol import cmd,stored

set depth_cue, 1
set fog_start, 0.4

set_color b_col, [36,36,85]
set_color t_col, [10,10,10]
set bg_rgb_bottom, b_col
set bg_rgb_top, t_col      
set bg_gradient

set  spec_power  =  200
set  spec_refl   =  0

load "data/receptor.pdb", protein
create ligands, protein and organic
select xlig, protein and organic
delete xlig

hide everything, all

color white, elem c
color bluewhite, protein
#show_as cartoon, protein
show surface, protein
#set transparency, 0.15

show sticks, ligands
set stick_color, magenta






# SAS points

load "data/receptor.pdb_points.pdb.gz", points
hide nonbonded, points
show nb_spheres, points
set sphere_scale, 0.2, points
cmd.spectrum("b", "green_red", selection="points", minimum=0, maximum=0.7)


stored.list=[]
cmd.iterate("(resn STP)","stored.list.append(resi)")    # read info about residues STP
lastSTP=stored.list[-1] # get the index of the last residue
hide lines, resn STP

cmd.select("rest", "resn STP and resi 0")

for my_index in range(1,int(lastSTP)+1): cmd.select("pocket"+str(my_index), "resn STP and resi "+str(my_index))
for my_index in range(1,int(lastSTP)+1): cmd.show("spheres","pocket"+str(my_index))
for my_index in range(1,int(lastSTP)+1): cmd.set("sphere_scale","0.4","pocket"+str(my_index))
for my_index in range(1,int(lastSTP)+1): cmd.set("sphere_transparency","0.1","pocket"+str(my_index))



set_color pcol1 = [0.361,0.576,0.902]
select surf_pocket1, protein and id [2995,3154,2071,2928,2925,2927,2934,2425,2664,2433,2662,2431,2432,2428,2437,2996,2960,2919,157,131,132,122,2921,134,121,2923,130,127,126,128,2442,2441,2443,841,2687,2686,2435,2487,3129,3128,2486,3123,3112,3115,3096,3111,3119,3120,3109,135,2485,2444,2478,2445,2477,1366,1393,1394,1395,1396,1397,2461,81,136,138,142,144,1355,1353,2017,1363,1352,1764,832,837,835,833,840,877,838,874,1392,1120,1143,1129,1132,1130,1408,1142,1412,1133,1409,1410,1411,1417,878,1415,882,885] 
set surface_color,  pcol1, surf_pocket1 
set_color pcol2 = [0.416,0.278,0.702]
select surf_pocket2, protein and id [2234,2373,2369,2368,2375,3646,3643,2376,3684,3712,3680,3683,3673,2202,2235,2236,2233,3685,3686,2261,3020,2263,2203,2205,2224,3711,2227,2225,2226,3671] 
set surface_color,  pcol2, surf_pocket2 
set_color pcol3 = [0.902,0.361,0.878]
select surf_pocket3, protein and id [2969,2970,2125,2071,2057,2068,2066,2126,2940,120,156,122,2035,2031,390,392,644,153,643,2059,2058,176,99,95,92,93,94] 
set surface_color,  pcol3, surf_pocket3 
set_color pcol4 = [0.702,0.278,0.380]
select surf_pocket4, protein and id [3391,3759,3291,3393,3417,3310,3289,3776,3396,3758,3283,2010,3769,3145,3774,3763,3398,3770,3771,3782,2020,2014,3807,3814,2007,2006] 
set surface_color,  pcol4, surf_pocket4 
set_color pcol5 = [0.902,0.620,0.361]
select surf_pocket5, protein and id [680,679,677,452,1045,1043,1010,280,297,1002,1033,1046,1032,1001,1000] 
set surface_color,  pcol5, surf_pocket5 




deselect

orient

from pymol import cmd,stored

set depth_cue, 1
set fog_start, 0.4

set_color b_col, [36,36,85]
set_color t_col, [10,10,10]
set bg_rgb_bottom, b_col
set bg_rgb_top, t_col      
set bg_gradient

set  spec_power  =  200
set  spec_refl   =  0

load "data/receptor.pdb", protein
create ligands, protein and organic
select xlig, protein and organic
delete xlig

hide everything, all

color white, elem c
color bluewhite, protein
#show_as cartoon, protein
show surface, protein
#set transparency, 0.15

show sticks, ligands
set stick_color, magenta






# SAS points

load "data/receptor.pdb_points.pdb.gz", points
hide nonbonded, points
show nb_spheres, points
set sphere_scale, 0.2, points
cmd.spectrum("b", "green_red", selection="points", minimum=0, maximum=0.7)


stored.list=[]
cmd.iterate("(resn STP)","stored.list.append(resi)")    # read info about residues STP
lastSTP=stored.list[-1] # get the index of the last residue
hide lines, resn STP

cmd.select("rest", "resn STP and resi 0")

for my_index in range(1,int(lastSTP)+1): cmd.select("pocket"+str(my_index), "resn STP and resi "+str(my_index))
for my_index in range(1,int(lastSTP)+1): cmd.show("spheres","pocket"+str(my_index))
for my_index in range(1,int(lastSTP)+1): cmd.set("sphere_scale","0.4","pocket"+str(my_index))
for my_index in range(1,int(lastSTP)+1): cmd.set("sphere_transparency","0.1","pocket"+str(my_index))



set_color pcol1 = [0.361,0.576,0.902]
select surf_pocket1, protein and id [1298,1972,1556,2008,2010,1376,1558,1942,1940,1941,1402,1261,1269,1262,1274,1260,1259,1273,1270,1264,1268,1279,1267,1265,5209,1584,1283,1276,1280,1285,5210,5509,5511,5510,5508,5513,5507,5450,5448,5478,5449,5451,5479,1997,1359,1302,1299,1347,1355,1346,1342,1345,1354,1348,1341,1352,1351,1326,1327,5789,5770,1353,5771,5772,1374,5471,5470,5480,5467,1343,5702,5469,5452,5698,5453,5697,5714,5710,5707,5708,5711,5704,4152,1286,4150,4142,4151,5168,4140,5182,2491,5181,5178,5183,2489,2490,4147] 
set surface_color,  pcol1, surf_pocket1 
set_color pcol2 = [0.278,0.333,0.702]
select surf_pocket2, protein and id [1542,1543,1545,5260,5351,1207,1522,1524,1208,5353,5352,1246,5261,5267,5349,5387,5382,1221,1226,5386,1227,1230,1521] 
set surface_color,  pcol2, surf_pocket2 
set_color pcol3 = [0.443,0.361,0.902]
select surf_pocket3, protein and id [1090,1117,1105,1098,1062,1061,1018,1021,1976,1046,1047,1053,1096,1102,2021,2019,2024,2022,2041,2047,2030,1978,1977,2050,2005] 
set surface_color,  pcol3, surf_pocket3 
set_color pcol4 = [0.463,0.278,0.702]
select surf_pocket4, protein and id [1457,1499,1500,1485,6704,1453,1451,1454,6710,1215,5415,5418,1217,1460,5414,6725,1424,5668,6726,6709,6724,6707,6701,6717] 
set surface_color,  pcol4, surf_pocket4 
set_color pcol5 = [0.741,0.361,0.902]
select surf_pocket5, protein and id [4111,4112,4102,4104,3897,4192,4186,4205,4207,4208,4209,4206,4204,4199,2752,3559,2733,2732] 
set surface_color,  pcol5, surf_pocket5 
set_color pcol6 = [0.694,0.278,0.702]
select surf_pocket6, protein and id [7313,7415,7417,7281,7371,7375,7377,7469,7468,6463,7367,7376,6462,7341,7163,7136,7340,7165,7393] 
set surface_color,  pcol6, surf_pocket6 
set_color pcol7 = [0.902,0.361,0.757]
select surf_pocket7, protein and id [4065,4064,2565,4051,4056,4066,4068,4070,4069,2708,2711,2710,3018,2706,2707,3038,3486,3036,2583,2581,2704,3039,2703,3487,3494] 
set surface_color,  pcol7, surf_pocket7 
set_color pcol8 = [0.702,0.278,0.475]
select surf_pocket8, protein and id [3559,2733,2732,2759,2760,3560,2761,3536,3520,2718,3568,3592,3591,3516,3513,3510,3517,2702] 
set surface_color,  pcol8, surf_pocket8 
set_color pcol9 = [0.902,0.361,0.459]
select surf_pocket9, protein and id [3678,3717,3735,3714,3337,3713,3709,3712,3336,3363,3667,2797] 
set surface_color,  pcol9, surf_pocket9 
set_color pcol10 = [0.702,0.318,0.278]
select surf_pocket10, protein and id [6226,6189,6839,6800,6801,6802,7183,7182,6812,5968,6807,6776,6806] 
set surface_color,  pcol10, surf_pocket10 
set_color pcol11 = [0.902,0.561,0.361]
select surf_pocket11, protein and id [3203,2622,3225,2979,3166,3167,2671,2672,2649,2978,2892,2890] 
set surface_color,  pcol11, surf_pocket11 
set_color pcol12 = [0.702,0.553,0.278]
select surf_pocket12, protein and id [4102,4100,4101,4104,3897,2551,2535,4087,2552,2733,2550,2725,2723] 
set surface_color,  pcol12, surf_pocket12 
set_color pcol13 = [0.902,0.859,0.361]
select surf_pocket13, protein and id [4199,2752,3559,2732,2759,2760,3560,2761,3536] 
set surface_color,  pcol13, surf_pocket13 




deselect

orient

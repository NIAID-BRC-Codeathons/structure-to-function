#!/usr/bin/env bash
set -e
conda activate docking
python bacteria_structure_docking.py 

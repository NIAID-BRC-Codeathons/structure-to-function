# Module 2 - structure & docking prep

## Task

upgrade bacteria_genome_analysis_upgraded.py to use the output fasta sequence, rank based on importance for pathogenicity (possibly literature), identify existing match in PDB, select top 50, if no PDB match use Boltz to create a pdbqt file and use prank (P2Rank) to predict pockets; add the rank reason, a link to the pdbqt, the pocket number and a link to the prank output into an interactive HTML report; put code, prompt, job and output in a folder with a timestamp. (conda activate docking; prank, vina, boltz available.)

## Invocation

```
bacteria_structure_docking.py
```

- Module-1 input: `./runs/20260918_101734_Chlamydia_trachomatis_D_UW_3_CX`
- Top N: 50
- Fold limit: 10

# Bacterial genome analysis — Chlamydia trachomatis D/UW-3/CX

- **BV-BRC genome id:** 272561.5  |  **taxon id:** 272561
- **Resolved via:** organism parsed from FASTA header: 'Chlamydia trachomatis'; resolved to BV-BRC genome 272561.5 (Chlamydia trachomatis D/UW-3/CX); REFERENCE LOOKUP ONLY: input FASTA sequence identity has not been established
- **Genome:** 1042519 bp, 41.3% GC, 968 CDS, status Complete, quality Good
- **Input FASTA:** /media/ping/Disk2/project/7Capability/2026Codathon/onsite/code4/GCA_963919375.1_B_HAR36.fasta.gz_genomic.fna.gz (8 seqs, 1036062 bp)
- **Generated:** 20260918_101734  |  **Engine:** BV-BRC Comprehensive Genome Analysis data API

## 1-3. Genes, proteins & functions
- CDS features (genes/proteins), source `PATRIC`: **968**  (with gene symbol: 559; all identified by locus tag / patric_id + product/function)
- Full table: `genes_proteins.csv`
- Example genes (identifier | function | length):
    - `fig|272561.5.peg.1`  fig|272561.5.peg.1  |  hypothetical protein  (340 aa)
    - `fig|272561.5.peg.2`  CT001  |  Uncharacterized membrane protein YuzA  (90 aa)
    - `fig|272561.5.peg.3`  gatC  |  Aspartyl-tRNA(Asn) amidotransferase subunit C (EC 6.3.5.6) @ Glutamyl-tRNA(Gln) amidotransferase subunit C (EC 6.3.5.7)  (100 aa)
    - `fig|272561.5.peg.4`  gatA  |  Aspartyl-tRNA(Asn) amidotransferase subunit A (EC 6.3.5.6) @ Glutamyl-tRNA(Gln) amidotransferase subunit A (EC 6.3.5.7)  (491 aa)
    - `fig|272561.5.peg.5`  gatB  |  Aspartyl-tRNA(Asn) amidotransferase subunit B (EC 6.3.5.6) @ Glutamyl-tRNA(Gln) amidotransferase subunit B (EC 6.3.5.7)  (488 aa)
    - `fig|272561.5.peg.6`  CT005  |  Inclusion membrane protein-1  (363 aa)
    - `fig|272561.5.peg.7`  CT006  |  Inclusion membrane protein-2  (189 aa)
    - `fig|272561.5.peg.8`  fig|272561.5.peg.8  |  hypothetical protein  (46 aa)

## 4. Taxonomy tree (comprehensive genome analysis)
```
Taxonomic lineage (root -> leaf):
└─ [cellular root] cellular organisms
  └─ [domain] Bacteria
    └─ [kingdom] Pseudomonadati
      └─ [clade] PVC group
        └─ [phylum] Chlamydiota
          └─ [class] Chlamydiia
            └─ [order] Chlamydiales
              └─ [family] Chlamydiaceae
                └─ [no rank] Chlamydia/Chlamydophila group
                  └─ [genus] Chlamydia
                    └─ [species] Chlamydia trachomatis
                      └─ [strain] Chlamydia trachomatis D/UW-3/CX
                        └─ * Chlamydia trachomatis D/UW-3/CX  (genome_id 272561.5)

Selected reference/representative genomes in the genus (not distance-ranked):
  - Candidatus Chlamydia corallus strain G3/2742-324  [Representative]  (Candidatus Chlamydia corallus)
  - Chlamydia sp. 2742-308  [Representative]  (Candidatus Chlamydia sanziniae)
  - Chlamydia abortus 15-70d24  [Representative]  (Chlamydia abortus)
  - Chlamydia abortus NL2354-2D  [Representative]  (Chlamydia abortus)
  - Chlamydia avium 10_881_SC42  [Representative]  (Chlamydia avium)
  - Chlamydia buteonis strain IDL17-4553  [Representative]  (Chlamydia buteonis)
  - Chlamydophila caviae GPIC  [Representative]  (Chlamydia caviae)
  - Chlamydia sp. No. 12  [Representative]  (Chlamydia crocodili)
  - Chlamydophila felis Fe/C-56  [Representative]  (Chlamydia felis)
  - Chlamydia gallinacea 08-1274/3  [Representative]  (Chlamydia gallinacea)
  - Chlamydiaceae bacterium 10-1398/6  [Representative]  (Chlamydia ibidis)
  - Chlamydia muridarum Nigg  [Representative]  (Chlamydia muridarum)
  - Chlamydophila pecorum E58  [Representative]  (Chlamydia pecorum)
  - Chlamydia pecorum strain DBDeUG_2018  [Representative]  (Chlamydia pecorum)
  - Chlamydophila pneumoniae TW-183  [Representative]  (Chlamydia pneumoniae)
```

## 5. Antimicrobial resistance (AMR)
- Laboratory AMR phenotypes: none recorded for this genome.
- Antibiotic-resistance genes (specialty genes, CARD/NDARO): **19**  (`amr_genes.csv`)
    - rplF  |  LSU ribosomal protein L6p (L9e)  [PATRIC ['antibiotic target in susceptible species']]
    - rpsJ  |  SSU ribosomal protein S10p (S20e)  [PATRIC ['antibiotic target in susceptible species']]
    - ileS  |  Isoleucyl-tRNA synthetase (EC 6.1.1.5)  [PATRIC ['antibiotic target in susceptible species']]
    - murA  |  UDP-N-acetylglucosamine 1-carboxyvinyltransferase (EC 2.5.1.7)  [CARD ['antibiotic target alteration']]
    - rho  |  Transcription termination factor Rho  [PATRIC ['antibiotic target in susceptible species']]
    - folA  |  Dihydrofolate reductase (EC 1.5.1.3)  [PATRIC ['antibiotic target in susceptible species']]
    - rpoC  |  DNA-directed RNA polymerase beta' subunit (EC 2.7.7.6)  [PATRIC ['antibiotic target in susceptible species']]
    - murA  |  UDP-N-acetylglucosamine 1-carboxyvinyltransferase (EC 2.5.1.7)  [PATRIC ['antibiotic target in susceptible species']]

## 6. Growth conditions
- **Gram stain:** -  _(this genome)_
- **Cell shape:** Rod  _(this genome)_
- **Motility:** No  _(species-typical (4 genomes))_
- **Optimal temperature (C):** 37  _(this genome)_
- **Temperature range:** Mesophilic  _(this genome)_
- **Habitat:** Host-associated  _(this genome)_

## 7. Isolation / geographic origin
- This genome:
    - **Disease:** ['Pharyngitis', 'Bronchitis', 'Pneumonitis']
- Species-wide isolation distribution (BV-BRC, top values) — context for *Chlamydia trachomatis*:
    - **Isolation country:** USA (70), Russia (16), Germany (14), United Kingdom (13), Portugal (11), Solomon Islands (10)
    - **Isolation source:** Freshwater lake (21), epithelial cells (20), cervical (14), Patient sample (12), in vitro (12), vaginal swab (11)
    - **Host:** Human, Homo sapiens (120), Homo sapiens (31), Macaca nemestrina (7)
    - **Geographic group:** North America (70), Europe (66), Oceania (10), Asia (7), Africa (5)
- Detail: `isolation_species_distribution.csv`

## 8. Nutrition requirement (inferred from encoded metabolism)
- **Oxygen requirement:** unknown
- Metabolic subsystem categories: Cofactors, Vitamins, Prosthetic Groups (79), Fatty Acids, Lipids, and Isoprenoids (37), Amino Acids and Derivatives (25), Carbohydrates (9), Metabolite damage and its repair or mitigation (5), Nucleosides and Nucleotides (3)
- Amino-acid biosynthesis subsystems encoded: **6** (more encoded pathways => less dependence on exogenous amino acids)
- Cofactor/vitamin biosynthesis subsystems encoded: **11**
- Detail: `nutrition_biosynthesis.csv`  (data-driven proxy; not a laboratory growth assay)

## 9. Virulence factors
- Virulence specialty genes (VFDB/Victors): **161**  (`virulence_factors.csv`)
    - -  |  hypothetical protein  [VFDB]
    - -  |  Inclusion membrane protein-1  [VFDB]
    - flhA  |  Similar to flagellar biosynthesis protein FlhA  [VFDB]
    - -  |  hypothetical protein  [VFDB]
    - -  |  hypothetical protein  [VFDB]
    - -  |  Inclusion membrane protein-7  [VFDB]
    - -  |  Inclusion membrane protein-13  [VFDB]
    - -  |  Inclusion membrane protein-16  [VFDB]
    - -  |  Inclusion membrane protein-31  [VFDB]
    - -  |  Inclusion membrane protein-38  [VFDB]

## 10. Close human pathogen(s)
- Related human-associated species (same genus as *Chlamydia trachomatis*), by number of human-host genomes:
    - *Chlamydia psittaci*  (31 human-host genomes)
    - *Chlamydia pneumoniae*  (13 human-host genomes)
    - *Chlamydia abortus*  (5 human-host genomes)
- Detail: `close_human_pathogens.csv`

## 11. Proteins involved in pathogenesis / host invasion
- Candidate proteins: **131** (virulence specialty genes + invasion/adhesion/secretion/toxin product matches)  (`pathogenesis_host_invasion.csv`)
    - `fig|272561.5.peg.1`  -  |  hypothetical protein  [virulence specialty gene]
    - `fig|272561.5.peg.6`  -  |  Inclusion membrane protein-1  [virulence specialty gene]
    - `fig|272561.5.peg.69`  flhA  |  Similar to flagellar biosynthesis protein FlhA  [virulence specialty gene]
    - `fig|272561.5.peg.90`  -  |  hypothetical protein  [virulence specialty gene]
    - `fig|272561.5.peg.115`  -  |  hypothetical protein  [virulence specialty gene]
    - `fig|272561.5.peg.126`  -  |  Inclusion membrane protein-7  [virulence specialty gene]
    - `fig|272561.5.peg.147`  -  |  Inclusion membrane protein-13  [virulence specialty gene]
    - `fig|272561.5.peg.193`  -  |  Inclusion membrane protein-16  [virulence specialty gene]
    - `fig|272561.5.peg.266`  -  |  Inclusion membrane protein-31  [virulence specialty gene]
    - `fig|272561.5.peg.413`  -  |  Inclusion membrane protein-38  [virulence specialty gene]
    - `fig|272561.5.peg.486`  -  |  hypothetical protein  [virulence specialty gene]
    - `fig|272561.5.peg.512`  -  |  Membrane protein insertion efficiency factor YidD  [virulence specialty gene]

---
_Source: BV-BRC (bv-brc.org) Data API. Specialty genes: CARD, NDARO, VFDB, Victors. Metadata completeness depends on the curated reference genome._

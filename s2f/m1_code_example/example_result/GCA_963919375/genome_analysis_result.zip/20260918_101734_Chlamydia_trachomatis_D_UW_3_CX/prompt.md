# Prompt (20260918_101734)

## Module 1 — original task

use minimal token to create code that will get a fasta file of bacteria genome to get gene, protein, function, taxonomy tree (using comprehensive genome analysis) AMR, growth condition, isolate location, nutrition requirement, virulent factor, close human pathogen, proteins involved in pathogeneisis host invation, make the code reusable, put prompt, code, output in this directory with time stamp

## Interactive-report upgrade

upgrade bacteria_genome_analysis.py to also output interactive html report for all genome features including active link to BVBRC genome report, any visualization that can link to disease symptom, spread invasion mechanism, searchable table for the proteins with functional annotation - hypothesis on mechanism, ranking of importance, access to protein sequences, python genetic tree to clearly demonstrate which one on the tree is a known pathogen to what disease, add references, this is module one for a larger project -- make sure the output of narrowed down protein sequences and annotation is easy to be used for next module, add references with beautiful publishable visual and make the code reusable, output prompt, code, output in subfolder with timedate as part of the folder name

---
Invocation:

    bacteria_genome_analysis_upgraded.py GCA_963919375.1_B_HAR36.fasta.gz_genomic.fna.gz
